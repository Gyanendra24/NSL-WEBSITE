<?php
session_start();
if(!isset($_SESSION['email'])){
    header('Location: index.php');
    
}
?>
   <html>
    <head>
	<link rel="stylesheet" type="text/css" href="admin_signin_style.css">
	<style>
		#holder{
			height: 500px;
		}
	</style>
	</head>
    <body style="background: radial-gradient(#99ffff 5%, #0099ff 15%, #890C16 60%);">
        <h2 style="text-align: center; color: white;">Update Details of the Admin </h2>
        <form action="update_admin_image.php" method="post" enctype="multipart/form-data">
            <center><div id="holder">
			<table align="center">
            <tr><td><input type="text" name="id"  value="<?php echo $_GET['y'];?>" required><br><br></td></tr>
            <tr><td><input type="text" name="name" placeholder="enter the name" required><br><br></td></tr>
            <tr><td><input type="text" name="phone" placeholder="enter the phone number" required><br><br></td></tr>
            <tr><td><input type="email" name="email" placeholder="enter the Email" required><br><br></td></tr><br>
            <tr><td><input type="text" name="sem" placeholder="Profession" required><br><br></td></tr>
            <tr><td><input type="file" name="image" required><br><br></td></tr>
            <tr><td><button name="submit" type="submit" value="<?php echo $_GET['y'];?>">Submit</button></td></tr>
            </table></div></center>
        </form>
        
    </body>
</html>