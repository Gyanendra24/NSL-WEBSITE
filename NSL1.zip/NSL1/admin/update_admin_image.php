<?php
session_start();
if(!isset($_SESSION['email'])){
    header('Location: index.php');
    
}
?>
   <?php
    include("connection.php");

if(isset($_POST['submit'])){
    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $sem  = $_POST['sem'] ;
    $phone = $_POST['phone'];
    $x=$_POST['id'];
    $file = addslashes(file_get_contents($_FILES['image']['tmp_name']));
    $query="UPDATE `update_admin_details` SET name ='$name',email='$email',phone='$phone',sem='$sem',pic='$file' WHERE sno='$x'";
    
    if(mysqli_query($conn,$query)){
        header('Location: display.php');
    }
    else{
        echo "you got an error:";
    }
}
mysqli_close($conn);
?>