
<html>
<head>
<title>Admin Login Form</title>
<link rel="stylesheet" type="text/css" href="../css/style1.css">
<link rel="stylesheet" type="text/css" href="admin_signin_style.css">
</head>
<body style="background-image: url(3.jpg)">
   <br><br><br><br>
    <form method="post" action="validate_login.php" >
      <center><div id="holder">
	  <p>Admin Login</p>
       <table align="center" cellpadding=17px>
       <tr>
       <td style="border: none;">
        <input type="email" name="email" placeholder="Email">
           <br>
           </td>
           
           </tr>
           
           <tr>
            <td>
               <input type="password" name="pass" placeholder="Password">
               <br>
               
               </td></tr>
               
           <tr><td><input type="submit" name="submit"></td></tr>
        </table> 
         </div></center>
    </form>
</body>
</html>