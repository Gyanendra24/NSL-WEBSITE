<?php

if(!isset($_SESSION['email'])){
    header('Location: index.php');
    
}
?>
<?php 
include('connection.php');
?>

<!DOCTYPE html>
<html>
<head>
     <link rel="stylesheet" href="design.css">
</head>
<body>
    <h3><u>Time Table</u></h3>
    <h6 align="right"><a href="home.php">Click here to go at the home menu</a></h6>

<?php

$sql = "SELECT * FROM update_time_table";
$result = mysqli_query($conn, $sql);
   
if (mysqli_num_rows($result) > 0) {
    echo "<table id='customers'>
  <tr>
    <th>Days</th>
    <th>10:00 - 12:00 </th>
    <th>1:00 - 5:00</th>
    <th>5:00 - 7:00</th>
    <th>8:00 - 12:00</th>
    <th>Action</th>
  </tr>";
    
    while($row = mysqli_fetch_assoc($result)) {
         echo "<tr>";

  echo "<td>" . $row['Days'] . "</td>";

  echo "<td>" . $row['10-12'] . "</td>";

  echo "<td>" . $row['1-5'] . "</td>";

  echo "<td>" . $row['5-7'] . "</td>";
  
  echo "<td>" . $row['8-12'] . "</td>";
  echo '<td> <a href="update_time_table.php?x='.$row['Days'].'">Update</a></td>';
        
  echo "</tr>";

  }
  
   
} else {
    echo "0 results";
}
?>
    
   


</body>
</html>
