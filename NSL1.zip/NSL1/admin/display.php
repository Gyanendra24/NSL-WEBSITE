<?php
session_start();
if(!isset($_SESSION['email'])){
    header('Location: index.php');
    
}
?>
<?php
include('time_table.php');
?>



<?php
include('connection.php');

$sql = "SELECT * FROM `update_admin_details`";
$result = mysqli_query($conn, $sql);
   
if (mysqli_num_rows($result) > 0) {
    echo "<table id='customers'>

<tr>
    <th>Id</th>
    <th>Name</th>
    <th>Email</th>
    <th>Mobile</th>
    <th>profession</th>
    <th>Image</th>
    <th>Action</th>
</tr>";
    
    while($row = mysqli_fetch_assoc($result)) {
         echo "<tr>";

  echo "<td>" . $row['sno'] . "</td>";

  echo "<td>" . $row['name'] . "</td>";

  echo "<td>" . $row['email'] . "</td>";

  echo "<td>" . $row['phone'] . "</td>";
  
  echo "<td>" . $row['sem'] . "</td>";
        
  echo'<td> <img src="data:image/jpeg;base64, '.base64_encode($row['pic']).'" height="50"></td>';
  echo '<td> <a href="update_admin.php?y='.$row['sno'].'">Update</a></td>';

  echo "</tr>";

  }
   
} else {
    echo "0 results";
}
?>

<?php 
include('connection.php');
?>

    <h3><u>Admin Details</u></h3>
   