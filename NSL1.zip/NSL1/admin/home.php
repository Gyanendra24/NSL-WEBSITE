<?php
session_start();
if(!isset($_SESSION['email'])){
    header('Location: index.php');
    
}
?>
<html>
<head>
<tiitle>
</tiitle>
</head>
<body>
    
    
  
    <a href="display.php"><h3>Display</h3></a>
    <a href="logout.php"><h3>Logout</h3></a>
    

</body>
</html>