<?php

include('connection.php');
if(isset($_POST['submit'])){

$email = $_POST["email"];
$pass = $_POST["pass"];

    $query="SELECT * FROM admin WHERE email = '$email'";
$result = mysqli_query($conn,$query);

$row = mysqli_fetch_array($result);

if($row['email']==$email && $row['password']==$pass)
{
    session_start();
    $_SESSION['email']=$email;
    header("Location: home.php");
}
else
    echo"Sorry, your credentials are not valid, Please try again.";
}
?>