<?php
session_start();
if(!isset($_SESSION['email'])){
    header('Location: index.php');
    
}
?>
   <html>
   
   <head>
	<link rel="stylesheet" type="text/css" href="admin_signin_style.css">
	<style>
		#holder{
			height: 500px;
			
		}
	</style>
   </head>
    <body style="background: radial-gradient(#99ffff 5%, #0099ff 15%, #890C16 60%);">
        <h2 style="text-align: center; color: white;">Update Details of Time Table</h2>
        <form action="UpdateTimeTable.php" method="post">
            <center><div id="holder"><table align="center">
           
                <tr><td><p>10:00-12:00&nbsp;</p><input type="text" name="name1"  value="-"><br><br></td></tr>
                <tr><td><p>01:00-05:00&nbsp;</p><input type="text" name="name2"  value="-"><br><br></td></tr>
                <tr><td><p>05:00-07:00&nbsp;</p><input type="text" name="name3"  value="-"><br><br></td></tr><br>
                <tr><td><p>08:00-12:00&nbsp;</p><input type="text" name="name4"  value="-"><br><br></td></tr>
            
            <tr><td><button name="submit" type="submit" value="<?php echo $_GET['x'];?>">Submit</button></td></tr>
            </table></div><center>
        </form>
        
    </body>
</html>