

<!DOCTYPE html>
<html>
<title>Login Form</title>
<meta charset="UTF-8">
<!--meta name="viewport" content="width=device-width, initial-scale=1"-->
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="../css/style1.css">
<style type="text/css">
  .login {
  width: 400px;
}
  .login input{
    width: 100%;
  }
  
  
  
  

</style>
</head>
<body>

<!-- html form login -->
<div class="login">
  
  <h2 class="login-header"  style="background-color: #890C16;">Log in</h2>
  <form class="login-container"  method="POST" action="validate_login.php" enctype="multipart/form-data">
    <p><input type="email" placeholder="email" name="email"></p>
    <p><input type="password" placeholder="Password" name="pass"></p>
    <p><input type="submit"  style="background: #890C16;" value="Log in"></p>
  </form>
</div>

<!-- javascript section -->


</div>
<script type="text/javascript" src="script.js"></script>
      </body>
</head>