<?php
session_start();
if(!isset($_SESSION['email'])){
    header('Location: index.php');
    
}
?>
   <?php
    include("connection.php");

if(isset($_POST['submit'])){
    
    $name1 = $_POST['name1'];
    $name2 = $_POST['name2'];
    $name3 = $_POST['name3'];
    $name4 = $_POST['name4'];
     $x=$_POST['submit'];
    
    $query="UPDATE `update_time_table` SET `10-12`='$name1',`1-5`='$name2',`5-7`='$name3',`8-12`='$name4' WHERE Days='$x'";
    
    if(mysqli_query($conn,$query)){
     header('Location: display.php');
    }
    else{
        echo "you got an error:";
    }
}
mysqli_close($conn);
?>