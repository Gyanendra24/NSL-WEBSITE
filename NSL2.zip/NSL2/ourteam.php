<html>
<head></head>
<body>
<ul> 
<?php for($i=1;$i<=5;$i++){ ?>
<li>Menu Item <?php echo $i; ?></li> 
<?php } ?>
</ul> 
</body>
</html>