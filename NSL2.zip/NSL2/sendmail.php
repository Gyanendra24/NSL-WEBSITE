<?php
	if(isset($_POST["btnsubmit"]))
	{
	
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html; charset=utf-8" . "\r\n";
	$headers .= "Content-type:image/gif; Content-Transfer-Encoding: base64" . "\r\n";
	
	$rc = "info@may91solutions.com";
	$txtname=$_POST["txtname"];
        $txtemail=$_POST["txtemail"];
        $sub = "Enquiry May91Solutions ".$txtname;
	$headers .= "From: ".$txtemail."";			
	$headers .= "";
        
        $cnt=$_POST["txtmessage"];
        
        
	//mail($rc, $sub, $cnt, "Content-type:text/html; charset=utf-8" . "\r\n"."From:".$txtemail."");
        
        mail($rc, $sub, $cnt, $headers);
	
	echo "<script language='javascript'>alert('Message Sent.');</script>";
        echo "<script language='javascript'>location.href='index.html';</script>";
							
        }
?>