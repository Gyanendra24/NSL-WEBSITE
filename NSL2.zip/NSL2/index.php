<!DOCTYPE html>
<html>

<head>
  <title>NSL - Network SYSTEM LABOURATRY</title>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- css -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700|Open+Sans:400,300,700,800" rel="stylesheet" media="screen">

  <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
  <link href="css/style.css" rel="stylesheet" media="screen">
  <link href="color/default.css" rel="stylesheet" media="screen">

<style>.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
    </style>
  <!-- =======================================================
    Theme Name: NETWORK SYSTEM LAB
    Theme URL: https://
    Author NAME-: Gyanendra Vishwakarma NIT CALICUT (MCA 3nd year) 
  =============================================================-->
</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-default" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
          <span class="sr-only">Toggle nav</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>


        <!-- Logo text or image -->

	</div>
        <a class="navbar-brand" href="admin/index1.php">NETWORK SYSTEM LAB</a>
      <div class="navigation collapse navbar-collapse navbar-ex1-collapse">
          <div class="nav navbar-nav">
          <li class="current"><a href="#intro">Home</a></li>
          <li><a href="#about">About Us</a></li>
          <li><a href="#services">Tutorials</a></li>
          <li><a href="#portfolio">Gallery</a></li>
          <li><a href="#TIMING">Timing</a></li>
	      <li><a href="#team">TEAM</a></li>
          <li><a href="#contact">Contact</a></li>
         
          </div> 
          
      </div>
    </div>
  </nav>

                                 <!--********** intro area **********-->
  <div id="intro">
    <div class="intro-text">
      <div class="container">
        <div class="col-md-12">
          <div id="rotator">
            <h1><span class="1strotate">NETWORK SYSTEM LAB, CHANGE FOR FUTURE, Creativity and technology</span></h1>
            <div class="line-spacer"></div>

            <p><span class="2ndrotate">We Are Creative, Build Yourself,All For your's </span></p>
          </div>
        </div>

		
	 <!-- ********* clock  source section **********   -->



<div id="clockbox" style="font:20pt Arial; color:#fff;"></div>
<script type="text/javascript">
var tday=["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
var tmonth=["January","February","March","April","May","June","July","August","September","October","November","December"];
function GetClock(){
var d=new Date();
var nday=d.getDay(),nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getFullYear();
var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

if(nhour==0){ap=" AM";nhour=12;}
else if(nhour<12){ap=" AM";}
else if(nhour==12){ap=" PM";}
else if(nhour>12){ap=" PM";nhour-=12;}

if(nmin<=9) nmin="0"+nmin;
if(nsec<=9) nsec="0"+nsec;

var clocktext=""+tday[nday]+", "+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
document.getElementById('clockbox').innerHTML=clocktext;
}

GetClock();
setInterval(GetClock,1000);
</script>	
      </div>
    </div>
  </div>

                                                   <!--*************** About *************-->


  <section id="about" class="home-section bg-white">
    <div class="container">
      <div class="row">
        <div class="col-md-offset-2 col-md-8">
          <div class="section-heading">
            <h2><font color ="#347C98">About us</font></h2>
            <div class="heading-line"></div>
            <p><font color="#3CB371"> An Effective ideas Which can we build for future from over the years.</font></p>
          </div>
        </div>
      </div>
      <div class="row wow fadeInUp">
        <div class="col-md-6 about-img">
          <img src="img/about-img.jpg" alt="">
        </div>

        <div class="col-md-6 content">
          <h2><font color="#FF1493">Your ideas and invention can make you perfect, And we are here to help you</font></h2>
          <h3><font color="#3CB371">We Respect your views and openion you little bit closure to your Dream</font></h3>
          <p><font color="#808000">Network System Lab is for CSED students (specially for MCA). It provides the infrastructure and facilities for conducting the regular labs (Data Structures Lab, DBMS Lab, Network Lab, and Programming Languages Lab) and project works for the MCA Programs. The lab is equipped with state of the art servers, desktops and software (Linux and compilers for C, C++, Perl, TCL, PHP, Java, Python, etc.). It maintained by the prestigious CSED, NIT Calicut; where the bright Master of Computer Application students have been regularly developing and testing their creative project.</font></p>
        </div>
      </div>
    </div>


				<!-- system specification and ip address code section -->


				<div class="clearfix">
					<article class="col-md-4 col-sm-4 col-xs-12 clearfix wow fadeInUp" data-wow-duration="500ms">
						<div class="note">
							
							<div class="excerpt">
								<h3><center><b><font color="#347C98">Server</font></b></center></h3>
								<table class="table">
                            		<tbody>
                            			<tr>
                                			<th colspan="2" class="text-center"><font color="#e6001a">Dell PowerEdge 2950 Rack Server</font></th>
                            			</tr>
                            			<tr>
                                			<td>CPU</td>
                                			<td>Intel(R) Core(TM) i5-3470 CPU @ 3.20GHz</td>
                            			</tr>
                            			<tr>
			                                <td>Memory</td>
			                                <td>8 GB</td>
			                            </tr>
			                            <tr>
			                                <td>HDD</td>
			                                <td>2.5 TB</td>
			                            </tr>
			                            <tr>
			                                <td>OS</td>
			                                <td>Ubuntu 16.04.3 LTS</td>
			                            </tr>
			                        </tbody>
			                	</table>
								
							</div>
						</div>						
					</article>
	
		<article class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="500ms" data-wow-delay="400ms">
						<div class="note">
							
							<div class="excerpt">
								<h3><center><b><font color="#347C98">Workstations</font></b></center></h3>
								<table class="table">
		                            <tbody>
			                            <tr>
			                                <th colspan="2" class="text-center"><font color="#e6001a">Dell</font></th>
			                            </tr>
			                            <tr>
			                                <td>CPU</td>
			                                <td>Intel(R) Xeon(R) CPU E5-1620 v2 @ 3.70GHz</td>
			                            </tr>
			                            <tr>
			                                <td>Memory</td>
			                                <td>8 GB</td>
			                            </tr>
			                            <tr>
			                                <td>HDD</td>
			                                <td>1 TB</td>
			                            </tr>
			                            <tr>
			                                <td>OS</td>
			                                <td>Ubuntu 16.04.3 LTS</td>
			                            </tr>
		                        	</tbody>
		                    	</table>
								
							</div>
						</div>						
					</article>
					
			<div>
					<article class="col-md-4 col-sm-4 col-xs-12 wow fadeInUp" data-wow-duration="500ms" data-wdelay="600ms">
						<div class="note kill-margin-bottom">
							<div class="media-wrapper">
								
							</div>
							<div class="excerpt">
								<h3><center><b><font color="#347C98">Systems</font></b></center></h3>
								<table class="table">
		                            <tbody>
			                            <tr>
			                                <th colspan="2" class="text-center"><font color="#e6001a">Dell</font></th>
			                            </tr>
			                            <tr>
			                                <td>CPU</td>
			                                <td>Intel(R) Core(TM) i5-3470 CPU @ 3.20GHz</td>
			                            </tr>
			                            <tr>
			                                <td>Memory</td>
			                                <td>4 GB</td>
			                            </tr>
			                            <tr>
			                                <td>HDD</td>
			                                <td>500 GB</td>
			                            </tr>
			                            <tr>
			                                <td>OS</td>
			                                <td>Ubuntu 16.04.3 LTS</td>
			                            </tr>
			                        </tbody>
			           			</table>
								
							</div>
						</div>						
					</article>
	
		</div>

		

				<!--ip details here-->

				<div class="col-md-6 col-sm-6 col-xs-12" style="text-align: center;">
					<h3 style="color: #6cb670;">
						<marquee scrollamount="5" width="40">&lt;&lt;&lt;</marquee><font color="#347C98">IP Range</font><marquee scrollamount="5" direction="right" width="40">&gt;&gt;&gt;</marquee>
					</h3>
		<!--p><b>Subnet Mask</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><u>255.255.255.0</u></a></p-->
			<p><b>Default gateway</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><u>192.168.41.1</u></a></p>
		<p><b>Preferred DNS Server</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><u>192.168.254.3</u></a></p>
		<p><b>Alternate DNS Server</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><u>192.168.254.5</u></a></p>
				</div>

				<div class="col-md-6 col-sm-6 col-xs-12" style="text-align: center;">
					<h3 style="color: #6cb670;">
						<marquee scrollamount="5" width="40">&lt;&lt;&lt;</marquee><font color="#347C98">Server Range</font><marquee scrollamount="5" direction="right" width="40">&gt;&gt;&gt;</marquee>
					</h3>
					<p><b>Andromeda Internal IP</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://192.168.41.100/"><u>192.168.41.100</u></a></p>
					<p><b>Andromeda External IP</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://124.124.70.86/"><u>124.124.70.86</u></a></p>
					<p><b>Backup Server</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://192.168.41.101/"><u>192.168.41.101</u></a></p>
					<!--p><b>Exam Server</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://192.168.41.99/"><u>192.168.41.99</u></a></p-->
				</div>

			</div>
		</div>

			        	

                                                       <!-- Services -->

  <section id="services" class="home-section bg-white">
    <div class="container">
      <div class="row">
        <div class="col-md-offset-2 col-md-8">
          <div class="section-heading">
            <h2><font color="#347C98">TUTORIALS</font></h2>
            <div class="heading-line"></div>
        
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-12">
          <div id="carousel-service" class="service carousel slide">
            <div class="carousel-inner">
              <div class="item active">
                <div class="row">
                  <div class="col-sm-12 col-md-offset-1 col-md-6">
                    <div class="wow bounceInLeft">
                      <h4><font color="#e6001a">HOW TO LOGIN ANDROMIDA</font></h4> 
<p><font color="#808000">All the Andromeda user have username same as username NITC mail id. The default password for the andromeda account is their username. Andromeda users can change default password.</font></p>
								<p><font color="#808000">For 2016 Admission Batch username is of format < roll_no ></font></p>
								<p><font color="#808000">For 2017 Admission Batch username is of format < roll_no ></font></p>
								<p><font color="#808000">For 2017 Admission Batch username is of format < roll_no ></font></p>
								<p><font color="#808000">The users has been assigned a fixed disk space usage quota. User can check the quota by running the command 'quota's</font></p>
		         
                    </div>
                  </div>
                  <div class="col-sm-12 col-md-5">
                   <div class="andromeda-video">
                    <video width="420" height="340" controls>
                      <source src="videos/Andromeda.mp4" type="video/mp4">
                      <source src="movie.ogg" type="video/ogg">
                      Your browser does not support the video tag.
                    </video>
							</div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="col-sm-12 col-md-offset-1 col-md-6">
                    <div class="wow bounceInLeft">
			<h3><font color="#e6001a">How to Access to database</font></h3></br>
<p><font color="#808000">Andromeda also hosts MySQL server. All the Andromeda users have a database account. The username and default password of database is same as roll number. The database name is of format db_< roll-no > like if your roll number is m170368ca then database name is db_m170368ca.</font></p>
								                     

                    </div>
                  </div>
                  <div class="col-sm-12 col-md-5">
                    <div class="screenshot wow bounceInRight">
                      <img src="img/screenshots/2.png" class="img-responsive" alt="" />
                    </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="row">
                  <div class="col-sm-12 col-md-offset-1 col-md-6">
                    <div class="wow bounceInLeft">
                     
		<h3><font color="#e6001a">How to create a webpage</font></h3></br>
 <p><font color="#808000">Andromeda is powered by Apache Webserver 2.4.7. Users can host and publish their webpages on Andromeda Server. Andromeda supports PHP as server side scripting language with MySQL database. The webpages of user is available under http://andromeda.nitc.ac.in/~username/</font></p>


                    </div>
                  </div>
                  <div class="col-sm-12 col-md-5">
                    <div class="screenshot wow bounceInRight">
                      <img src="img/screenshots/3.png" class="img-responsive" alt="" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Indicators -->


            <ol class="carousel-indicators">
              <li data-target="#carousel-service" data-slide-to="0" class="active"></li>
              <li data-target="#carousel-service" data-slide-to="1"></li>
              <li data-target="#carousel-service" data-slide-to="2"></li>
            </ol>
          </div>
        </div>
  </section>

                       

                                     <!--****** Gallery Section *****  -->


  <section id="portfolio" class="home-section bg-gray">
    <div class="container">
      <div class="row">
        <div class="col-md-offset-2 col-md-8">
          <div class="section-heading">
            <h2><font color="#347C98">GALLERY</font></h2>
            <div class="heading-line"></div>
            <p> </p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-12">

          <ul id="og-grid" class="og-grid">
            <li>
              <a href="#" data-largesrc="img/works/1.jpg" data-title="NSL LAB" data-description=".Network System Lab is for CSED students (specially for MCA). It provides the infrastructure and facilities for conducting the regular labs (Data Structures Lab, DBMS Lab, Network Lab, and Programming Languages Lab) and project works for the MCA Programs. The lab is equipped with state of the art servers, desktops and software (Linux and compilers for C, C++, Perl, TCL, PHP, Java, Python, etc.). It maintained by the prestigious CSED, NIT Calicut; where the bright Master of Computer Application students have been regularly developing and testing their creative projects.">
								<img src="img/works/thumbs/1.jpg" alt=""/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/2.jpg" data-title="NSL LAB 2017"data-description=".Network System Lab is for CSED students (specially for MCA). It provides the infrastructure and facilities for conducting the regular labs (Data Structures Lab, DBMS Lab, Network Lab, and Programming Languages Lab) and project works for the MCA Programs. The lab is equipped with state of the art servers, desktops and software (Linux and compilers for C, C++, Perl, TCL, PHP, Java, Python, etc.). It maintained by the prestigious CSED, NIT Calicut; where the bright Master of Computer Application students have been regularly developing and testing their creative projects.">
								<img src="img/works/thumbs/2.jpg" alt=""/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/3.jpg" data-title="NSL LAB 2017" data-description=".Network System Lab is for CSED students (specially for MCA). It provides the infrastructure and facilities for conducting the regular labs (Data Structures Lab, DBMS Lab, Network Lab, and Programming Languages Lab) and project works for the MCA Programs. The lab is equipped with state of the art servers, desktops and software (Linux and compilers for C, C++, Perl, TCL, PHP, Java, Python, etc.). It maintained by the prestigious CSED, NIT Calicut; where the bright Master of Computer Application students have been regularly developing and testing their creative projects.">
								<img src="img/works/thumbs/3.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/4.jpg" data-title="Hackathon NITC" data-description="Let me pitch the idea. It is simple- a bunch of developers, software programmers or designers joining hands for a specified period, generally 24-48 hours, to build something awesome.
The participants basically try to ‘hack’ their way through the assigned task. It’s a fun environment where teams of 3-5 brainstorm with each other’s brilliant minds to create a virtual reality prototype over the weekend. The goal is to create a usable or a prototype software.">

								<img src="img/works/thumbs/4.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/5.jpg" data-title="Hackathon NITC" data-description="Beginning in the mid to late 2000s, hackathons spread like fire and made a place in the lives of venture capitalists and companies to develop new technologies. The very first hackathons were organized in 1999 by OpenBSD and Sun Microsystems which were conducted in-company.
As events hackathons are focused, cooperative, innovative and highly stimulative.">
								<img src="img/works/thumbs/5.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/6.jpg" data-title="hackathon NITC" data-description="Online/Offline- the name comes from the location. Online hackathons have everything from registration to judging online. Offline is conducted at a physical location.
Application-based- The focus is mobile app development, video game development or the desktop operating system.
Specific programming language- Dedicated to developing applications which use a specific framework like JavaScript, HTML.
The cause- The social hackathons aimed at addressing issues of health care, women empowerment, education.
Code sprints- They are the longest of hackathons that last for 2-3 weeks where programmers write codes to create a software.
Demographic groups- they are community specific and are majorly organised for brand awareness.">
								<img src="img/works/thumbs/8.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/7.jpg" data-title="TATHVA NITC" data-description="Tathva was originally conceived as a technical symposium that would be conducted on an annual basis, incorporating students from reputed engineering colleges and technology institutes of India on a national basis. The first such symposium took place in the year 2000. In 2002, Tathva was transformed into a larger framework that coalesced many contests, demonstrations and exhibitions, in addition to presentations, speeches, workshops and seminars. In 2007, the event was transformed to encompass technology and management">
								<img src="img/works/thumbs/7.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/8.jpg" data-title="TATHVA NITC" data-description="Tathva hosts competitions, exhibitions, seminars, workshops, symposiums, and keynote speeches. Events are graded at several levels targeted at the varying interests of attending participants, who may include visiting professors, students, industry experts, delegations from peer educational institutions, and general public. Some of the regular attractions are dedicated to innovations arising out of distinct faculties of engineering and technology from inside and the outside the academic setting.">
								<img src="img/works/thumbs/8.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/9.jpg" data-title="TATHVA NITC" data-description="Robotics,Wheels,Blitzkrieg,Electrical,Architecture,Online events,Workshops</h3>
Transporter: This event requires the modeling and construction of weight carrying robots or transporters which can lift weights and transport them from one area to another, as per the given specifications.
Mechanical.Contraption: This event focuses on the construction of innovative and complicated contraptions to complete a simple task, as per the given problem statement.">

								<img src="img/works/thumbs/9.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/10.jpg" data-title="Nakshatra 2017" data-description="Duo te dico volutpat, unum elit oblique per id. Ne duo mollis sapientem intellegebat. Per at augue vidisse percipit, pri vocibus assueverit interesset ut, no dolore luptatum incorrupte nec. In mentitum forensibus nec, nibh eripuit ut pri, tale illud voluptatum ut sea. Sed oratio repudiare ei, cum an magna labitur, eu atqui augue mei. Pri consul detracto eu, solet nusquam accusam ex vim.">
								<img src="img/works/thumbs/10.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/11.jpg" data-title="Nakshatra 2017" data-description="Vim ad persecuti appellantur. Eam ignota deterruisset eu, in omnis fierent convenire sed. Ne nulla veritus vel, liber euripidis in eos. Postea comprehensam vis in, detracto deseruisse mei ea. Ex sadipscing deterruisset concludaturque quo.">
								<img src="img/works/thumbs/11.jpg" alt="img01"/>
							</a>
            </li>
            <li>
              <a href="#" data-largesrc="img/works/12.jpg" data-title="Nakshatra 2017" data-description="Mea an eros periculis dignissim, quo mollis nostrum elaboraret et. Id quem perfecto mel, no etiam perfecto qui. No nisl legere recusabo nam, ius an tale pericula evertitur, dicat phaedrum qui in. Usu numquam legendos in, voluptaria sadipscing ut vel. Eu eum mandamus volutpat gubergren, eos ad detracto nominati, ne eum idque elitr aliquam.">
								<img src="img/works/thumbs/12.jpg" alt="img01"/>
							</a>
            </li>
          </ul>

        </div>
      </div>
    </div>
				
				                   <!--********* Timetable ********* -->
				
				
				
    <div>
			        	<h2 div id="TIMING"><font color="#347C98">Timing</font></h2>
				        <div class="border"></div>
				        <h3><font color="#347C98">9 A.M. - 12 P.M.</font></h3>
				    </div>
				   	<table class="table table-responsive table-hover text-center">  
			        	<tbody>
			        		<tr>
                                
			                    <th><font color="#e6001a">Day</font></th>
			                    <th class="text-center"><font color="#e6001a">10:00 - 12:00</font></th>
			                    <th class="text-center"><font color="#e6001a">01:00 - 05:00</font></th>
			                    <th class="text-center"><font color="#e6001a">05:00 - 07:00</font></th>
			                    <th class="text-center"><font color="#e6001a">08:00 - 12:00</font></th>
			                </tr>
			                <tr>
                            <?php
                                    include("connection.php");
                                    $sql = "SELECT * FROM update_time_table ";
                                    $result = mysqli_query($conn, $sql);
                                    if (mysqli_num_rows($result) > 0) {
                                        while($row = mysqli_fetch_assoc($result)) {
                                ?>
                                
			                    <th><?php echo $row["Days"]?></th>
			                    <td><?php echo $row["10-12"]?> </td>
			                    <td><?php echo $row["1-5"]?> </td>
			                    <td><?php echo $row["5-7"]?> </td>
			                    <td><?php echo $row["8-12"]?></td>
			                </tr>
			                 <?php
                                    }
                                }
                                else{
                                    echo 'not exits';
                                }
                            ?>
			                

                                          <!--******** Parallax 2 *******-->
										  
   		                   
			                     <td><?php echo $row["10-12"]?> </td>
			                    <td><?php echo $row["1-5"]?> </td>
			                    <td><?php echo $row["5-7"]?> </td>
			                    <td><?php echo $row["8-12"]?></td>
			                </tr>
			            </tbody>
			    	</table>  
 <center><a href="nsl_time_table.pdf" target="_blank" class="btn btn-transparent wow fadeInUp" data-wow-duration="500ms">Download Time Slots</a></center>
		</section>




  <section id="parallax2" class="home-section parallax" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <ul class="clients">
            <li class="wow fadeInDown" data-wow-delay="0.3s"><a href="#"><img src="img/clients/1.png" alt="" /></a></li>
            <li class="wow fadeInDown" data-wow-delay="0.6s"><a href="#"><img src="img/clients/2.png" alt="" /></a></li>
            <li class="wow fadeInDown" data-wow-delay="0.9s"><a href="#"><img src="img/clients/3.png" alt="" /></a></li>
            <li class="wow fadeInDown" data-wow-delay="1.1s"><a href="#"><img src="img/clients/4.png" alt="" /></a></li>
          </ul>
        </div>
      </div>
    </div>
	
	
	
  </section>
                                <!-- ********* team section  ***********-->
    <div class="container">
      
    </div>
  </section>
  
                      <!-- *********** team section  *******************      -->

 <section id="team" class="home-section bg-white">
    <div class="container">
      <div class="row">
        <div class="col-md-offset-2 col-md-8">
          <div class="section-heading">
	     <h2><font color="#347C98">OUR TEAM</font></h2>
            <div class="heading-line"></div>  
	<meta name="viewport" content="width=device-width, initial-scale=1">
        </div>
        </div>
      </div>
      
      <div class="row">

<?php
        $sql = "SELECT * FROM update_admin_details;";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
    ?>
  
    <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3" data-wow-delay="0.3s">
          <div class="box-team wow bounceInUp" >
           <?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $row['pic'] ).'" class="img-circle img-responsive" align="right" style="height:300px; width=320px;">';?>
            <h4><?php echo $row["name"]?></h4> 
            <p><?php echo $row["sem"]?></p>
          <p>MOB:+<?php echo $row["phone"]?></p>
          <p><?php echo $row["email"]?></p>
          </div>
          
    </div>
        <?php }}else{echo 'not exits';}?>
<center><a href="profile.html" class="btn btn-transparent wow fadeInUp" data-wow-duration="500ms">Our Developers</a></center>

  </section>


                                 

                                 <!--******************** Contact ************************-->


  <section id="contact" class="home-section bg-gray">
    <div class="container">
      <div class="row">
        <div class="col-md-offset-2 col-md-8">
          <div class="section-heading">
            <h2><font color="#347C98">Contact us</font></h2>
            <div class="heading-line"></div>
       <p>If you have any question just send it to respective authority  we will be get in touch with you within 24 hours. </p>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-offset-2 col-md-8">
          <div id="sendmessage">Your message has been sent. Thank you!</div>
          <div id="errormessage"></div>

          <form action="sendmail.php" method="post" class="form-horizontal contactForm" role="form">
            <div class="col-md-offset-2 col-md-8">
              <div class="form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validation"></div>
              </div>
            </div>

            <div class="col-md-offset-2 col-md-8">
              <div class="form-group">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                <div class="validation"></div>
              </div>
            </div>

            <div class="col-md-offset-2 col-md-8">
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validation"></div>
              </div>
            </div>

            <div class="col-md-offset-2 col-md-8">
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validation"></div>
              </div>
            </div>
            <div class="form-group">
              <div class="col-md-offset-2 col-md-8">
                <button type="submit" class="btn btn-theme btn-lg btn-block">Send message</button>
              </div>
            </div>
          </form>

        </div>
      </div>

    </div>
  </section>

                                                 <!--********* Bottom widget ***************-->


  <section id="bottom-widget" class="home-section bg-white">
    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <div class="contact-widget wow bounceInLeft">
            <i class="fa fa-map-marker fa-4x"></i>
            <h5>Main Office</h5>
            <p>
              ITL 304, IT Laboratory Complex,<br />National Institute of Technology Calicut, India (673601)
            </p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="contact-widget wow bounceInUp">
            <i class="fa fa-phone fa-4x"></i>
            <h5>Call</h5>
            <p>
              +91-7894561230 (Senior Lab In-Charge)<br>+91(495) 2286870/43 (Senior Lab In-Charge)<br> +91 8877-573-355( Student Admin)

            </p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="contact-widget wow bounceInRight">
            <i class="fa fa-envelope fa-4x"></i>
            <h5>Email us</h5>
            <p>
              jayarajpb@nitc.ac.in<br />biju@nitc.ac.in<br>bsknath@gmail.com
            </p>
          </div>
        </div>
      </div>
      <div class="row mar-top30">
        <div class="col-md-12">
          <h5><font color="#347C98">We're on social networks</font></h5>
          <ul class="social-network">
            <li><a href="https://www.facebook.com/nitcnsl">
						<span class="fa-stack fa-2x">
							<i class="fa fa-circle fa-stack-2x"></i>
							<i class="fa fa-facebook fa-stack-1x fa-inverse"></i>
						</span></a>
            </li>
            <li><a href="http://nitc.ac.in/">
						<span class="fa-stack fa-2x">
							<i class="fa fa-circle fa-stack-2x"></i>
							<i class="fa fa-dribbble fa-stack-1x fa-inverse"></i>
						</span></a>
            </li>
            <li><a href="#">
						<span class="fa-stack fa-2x">
							<i class="fa fa-circle fa-stack-2x"></i>
							<i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
						</span></a>
            </li>
            <li><a href="#">
						<span class="fa-stack fa-2x">
							<i class="fa fa-circle fa-stack-2x"></i>
							<i class="fa fa-pinterest fa-stack-1x fa-inverse"></i>
						</span></a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->

				
		
		<footer id="footer" class="bg-one">
			<div class="container">
			    <div class="row wow fadeInUp" data-wow-duration="500ms"></br>
					<div class="col-lg-12">
	<article class="col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp" data-wow-duration="200ms">
	<a href="http://minerva.nitc.ac.in/cse/" target="_blank" class="btn btn-transparent wow fadeInUp">CSED</a>
			</article>
		<article class="col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp" data-wow-duration="500ms" data-wow-delay="400ms">
	<a href="https://eduserver.cse.nitc.ac.in/" target="_blank" class="btn btn-transparent wow fadeInUp">CSED Eduserver</a>
				</article>
		<article class="col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp" data-wow-duration="500ms" data-wow-delay="600ms">
			<a href="http://nitc.ac.in/" target="_blank" class="btn btn-transparent wow fadeInUp">NITC HOME</a>
						</article>
	<article class="col-md-3 col-sm-6 col-xs-12 text-center wow fadeInUp" data-wow-duration="500ms" data-wow-delay="750ms">
	<a href="http://people.cse.nitc.ac.in/" target="_blank" class="btn btn-transparent wow fadeInUp">CSED People</a>
			</article>
						
				<div class="copyright text-center">
							
							
						
					</div>
				</div>
			</div>
		</footer>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <p>Copyright &copy;  2019 Network System Lab, NIT Calicut. All Rights Reserved.</p>
          <div class="credits">
          </div>
    </div>
  </footer>
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/wow.min.js"></script>
  <script src="js/mb.bgndGallery.js"></script>
  <script src="js/mb.bgndGallery.effects.js"></script>
  <script src="js/jquery.simple-text-rotator.min.js"></script>
  <script src="js/jquery.scrollTo.min.js"></script>
  <script src="js/jquery.nav.js"></script>
  <script src="js/modernizr.custom.js"></script>
  <script src="js/grid.js"></script>
  <script src="js/stellar.js"></script>



  <!-- Contact Form JavaScript File -->


  <script src="contactform/contactform.js"></script>

  <!-- Template Custom Javascript File -->


  <script src="js/custom.js"></script>
</body>
</head>
</html>    